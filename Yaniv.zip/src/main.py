from PlayerInterface import PlayerInterface


def main():
    PlayerInterface()


if __name__ == "__main__":
    main()