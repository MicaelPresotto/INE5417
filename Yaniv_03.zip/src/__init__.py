class __init__:
    def __init__(self):
        ...

    