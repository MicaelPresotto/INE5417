The game.id file contains the identifier of the game developed under dog framework. To produce it, run the file "generate_game_id.py" in this folder, just once:

python generate_game_id.py